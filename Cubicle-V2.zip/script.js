// variables for saving user's tasks inputs
var currentTasks = [];
var todayTasks = [];
// variables for calendar integrations
var iFrameLink = "";
var iFrameVar = "";
// the lines below populate a user's tasks and notes with values previously saved from local storage
document.getElementById("currenttask1").value = localStorage.getItem("currenttask1");
document.getElementById("currenttask2").value = localStorage.getItem("currenttask2");
document.getElementById("currenttask3").value = localStorage.getItem("currenttask3");
document.getElementById("todaytask1").value = localStorage.getItem("todaytask1");
document.getElementById("todaytask2").value = localStorage.getItem("todaytask2");
document.getElementById("todaytask3").value = localStorage.getItem("todaytask3");
document.getElementById("notes1").value = localStorage.getItem("notes");

// this if statment determines if we should show the inputs for integrating a user's calendar or not. We don't want to show that option if they've already done it, so if there is a link stored in local storage we will just embed the calendar instead of asking for the link again.
if (localStorage.getItem("googleCal") === null){
  console.log("it is null dude");
  document.getElementById("googleCalendar").style.display = "block";
  document.getElementById("calIframe").style.display= "none";
}
else {
  document.getElementById("calIframe").src = localStorage.getItem("googleCal");
  document.getElementById("googleCalendar").style.display = "none";
}

// same as above but for API key inputs
if (localStorage.getItem("apiKey") === null){
  document.getElementById("api-key").style.display = "block";
}
else {
  document.getElementById("api-key").style.display = "none";
  document.getElementById("submit-api-key").style.display = "none";
}

// ChromeGPT scripting to handle sending and receiving messages via OpenAI APIs

const submitApiKeyButton = document.getElementById('submit-api-key'); 
  const apiKeyInput = document.getElementById('api-key');
  const submitButton = document.getElementById('gptSubmit');
  const apiKeyLabel = document.getElementById('api-key-label'); 
  let apikey;

function sendAPIKey(){
  localStorage.setItem('apiKey', apiKeyInput.value);
  
    // Retrieve the API key from the input field
    const apiKey = apiKeyInput.value
    console.log(apiKey)

    // Hide the form
    apiKeyInput.style.display = 'none';
    submitApiKeyButton.style.display = 'none';
    
};
 function sendMessage() {
    // Get the input and output textarea elements
    const inputTextarea = document.getElementById('gptInput');
    const outputTextarea = document.getElementById('gptOutput');

    // Get the message from the input textarea
    const message = inputTextarea.value;
    console.log(message);
    // Clear the input textarea
    inputTextarea.value = '';

    // Retrieve the API key from the extension's local storage
    const apiKey = localStorage.getItem('apiKey')
      // Check if the API key was retrieved successfully
      if (apiKey != null) {
        // Send the message to the OpenAI API
        fetch('https://api.openai.com/v1/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            prompt: message,
            model: 'text-davinci-003',
            temperature: 0.3,
            max_tokens: 4000
          })
        })
        .then(response => response.json())
        .then(data => {
          // Check if the choices property exists before trying to access it
          console.log(data);
          const response = data.choices && data.choices[0].text;

// Append ChatGPT's response to the output textarea
outputTextarea.value += `\nChatGPT: ${response}`;

// Clear the input textarea
inputTextarea.value = '';
})
.then(response => {
console.log(response);
})
} 
};

// need to investigate if this is still needed, believe it is redundant since we are already checking if we have a user's calendar in the previous if else statement
function checkIframe(){
if (localStorage.getItem("googleCal") != null){
  document.getElementById("calIframe").src = localStorage.getItem("googleCal");
  document.getElementById("calIframe").style.display = "block";
}
}
// function for the reset timer button that gets run on click. Just refreshes the page to reset timer to twenty mins.
function resetTimer(){
  location.reload();
}

// this is the function that makes the timer actually work 
function myFunction() {
    var count = 1200;
    var myVar = setInterval(myTimer, 1000);
  
    function myTimer() {
        count--;
        var dateObj = new Date(count * 1000);
      
      var minutes = dateObj.getUTCMinutes();
      var seconds = dateObj.getSeconds();
        timeString = minutes.toString().padStart(2, '0')
                + ':' + seconds.toString().padStart(2, '0');
        document.getElementById("demo").innerHTML = timeString;
 }
     
        if (count == 0) {
            clearInterval(myVar);
        }
     
        }

// this function runs when a user hits the save button for the current tasks inputs. It saves the user inputs to the currentTasks array and saves them to local storage. 
function submitFunction() {
var currentTasks = [document.getElementById("currenttask1").value, document.getElementById("currenttask2").value, document.getElementById("currenttask3").value];
localStorage.setItem("currenttask1", currentTasks[0]);
localStorage.setItem("currenttask2", currentTasks[1]);
localStorage.setItem("currenttask3", currentTasks[2]);
console.log(currentTasks);
}

// this does the same as the above function but for the daily tasks.
function submitFunctionTwo() {
var todayTasks = [document.getElementById("todaytask1").value, document.getElementById("todaytask2").value, document.getElementById("todaytask3").value];
localStorage.setItem("todaytask1", todayTasks[0]);
localStorage.setItem("todaytask2", todayTasks[1]);
localStorage.setItem("todaytask3", todayTasks[2]);
console.log(todayTasks);
}

// this function is announces that there is an incoming memo from corporate. It retrieves the html element with id = scroll and makes that text scroll from right to left.
/*function scroll() {

document.getElementById("scroll").style.left=parseInt(document.getElementById("scroll").style.left)-1+"px";
setTimeout("scroll()",25);
//setTimeout("corporateMemo()", 15000);
}
*/
window.onload = function() {
  corporateMemo();
}
function corporateMemo(){
  // prompt for memo
  // only run after 15 seconds
  setInterval(corporateMemo, 300000);
  const memoMessage = "Send me a concise single sentence memo from corporate that does any one of the following: gives an inspirational quote, asks for a specific made up task to be completed soon, or divulges a specific piece of petty but innocent office gossip. Randomly pick one of those three topics, they are all acceptable. Start each sentence with the phrase: incoming memo. Do not start the sentence with anything but the phrase: incoming memo."

    // Retrieve the API key from the extension's local storage
    const apiKey = localStorage.getItem('apiKey')
      // Check if the API key was retrieved successfully
      if (apiKey != null) {
        // Send the message to the OpenAI API
        fetch('https://api.openai.com/v1/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            prompt: memoMessage,
            model: 'text-davinci-003',
            temperature: 1.0,
            max_tokens: 4000
          })
        })
        .then(response => response.json())
        .then(data => {
          // Check if the choices property exists before trying to access it
          
const response = data.choices && data.choices[0].text;

// Append ChatGPT's response to the output textarea
var memoResponse = response;
document.getElementById("memo").innerHTML = memoResponse;
console.log(memoResponse);
memoDiv.style.left = (window.innerWidth / 3) + "px";
runMemo(memoResponse);
}) 
}
}

function runMemo(memoResponse){
document.getElementById("memoDiv").style.left=parseInt(document.getElementById("memoDiv").style.left)-1+"px";
setTimeout("runMemo()",35);

}



// this function makes the actual memo from corporate scroll.
/*function corporateMemo() {
  const memoOptions = [document.getElementById("memo"), document.getElementById("memo1"), document.getElementById("memo2")];
  var randomMemo = Math.floor(Math.random() * memoOptions.length);
  var currentMemo = memoOptions[randomMemo];

setTimeout(function() {
    currentMemo.style.left=parseInt(currentMemo.style.left)-1+"px";;
  }, 35);
  return;
}*/




// this function runs when a user hits save on the notepad save button. It sets their input to local storage and the variable called notes.
function saveNotes(){
var notes = document.getElementById("notes1").value;
localStorage.setItem("notes", notes);
}

// this is the function that runs when a user hits submit on the calendar link input field. it first sets the input value to the variable googleCal and then sets that value to local storage. It then updates the google calendar div to not show anymore by modifying the display property in the CSS. Next, it retrieves the user's link from storage and sets it to the variable called iFrameLink and then sets the link to the src for the iFrame element in the html. 
function googleCalSubmit(){
  // save user embed code to variable and set to local storage
var googleCal = document.getElementById("googleCal").value;
localStorage.setItem("googleCal", googleCal);
  // after user submits embed code hide the input field and button
var divStyle = document.getElementById("googleCalendar");
if (divStyle.style.display !== "none") {
divStyle.style.display = "none";
 
}
else {
  divStyle.style.display = "block";
}
 // embed Calendar with user embed code
  var iFrameLink = localStorage.getItem("googleCal");
  var iFrameVar = document.getElementById("calIframe");
  iFrameVar.src = iFrameLink;
}